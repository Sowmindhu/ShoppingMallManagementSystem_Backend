package service.admin.mall;
import org.springframework.data.jpa.repository.JpaRepository;  


public interface MallAdminRepository extends JpaRepository<MallAdmin, Integer>{

}
